package com.dicoding.exam.exam4

// TODO
fun vehicle(): Map<String, String> {
    return mapOf(
        "type" to "motorcycle",
        "maxSpeed" to "230Km/s",
        "maxTank" to "100Ltr"
    )
}