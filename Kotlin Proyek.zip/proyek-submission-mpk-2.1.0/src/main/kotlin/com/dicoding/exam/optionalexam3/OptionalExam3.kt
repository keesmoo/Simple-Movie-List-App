package com.dicoding.exam.optionalexam3

// TODO
fun manipulateString(str: String, int: Int): String {
    val regex = "\\d+".toRegex()
    val result = regex.find(str)

    return if (result != null) {
        val numberInString = result.value.toInt()

        val multipliedValue = numberInString * int

        str.replace(result.value, multipliedValue.toString())
    } else {
        str + int
    }
}
