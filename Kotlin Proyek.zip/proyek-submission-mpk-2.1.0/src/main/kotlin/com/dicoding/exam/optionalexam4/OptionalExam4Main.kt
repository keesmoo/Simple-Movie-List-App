package com.dicoding.exam.optionalexam4

private fun main() {
    println(getMiddleCharacters("dicodingindonesia") == "i")
    println(getMiddleCharacters("dicoding") == "od")
    println(getMiddleCharacters("A") == "A")
}