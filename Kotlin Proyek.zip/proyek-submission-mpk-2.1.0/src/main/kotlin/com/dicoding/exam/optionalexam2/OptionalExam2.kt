package com.dicoding.exam.optionalexam2

// TODO
fun minAndMax(number: Int): Int {
    val digits = number.toString().map { it.toString().toInt() }

    val minDigit = digits.min()
    val maxDigit = digits.max()

    return minDigit + maxDigit
}
